package io.github.armorcurve.mixin;

import net.minecraft.world.damagesource.CombatRules;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Replaces vanilla's armor damage formula.
 *
 * damage taken = damage * 100 / (100 + 45 * armor)
 *
 * armor = 0  -> 100% of damage taken
 * armor = 20 -> 10% of damage taken (90% reduction)
 *
 * Armor toughness is not used (it is ignored by this formula).
 */
@Mixin(CombatRules.class)
public abstract class CombatRulesMixin {

	@Inject(method = "getDamageAfterAbsorb", at = @At("HEAD"), cancellable = true)
	private static void armorcurve$customArmor(LivingEntity victim, float damage, DamageSource source,
			float armor, float toughness, CallbackInfoReturnable<Float> cir) {
		float armorPoints = Math.max(0.0F, armor);
		cir.setReturnValue(damage * 100.0F / (100.0F + 45.0F * armorPoints));
	}
}
