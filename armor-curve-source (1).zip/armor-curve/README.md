# Armor Curve (Fabric, Minecraft 1.21.11)

Replaces vanilla armor math with:

    damage taken = damage * 100 / (100 + 45 * armor points)

| Armor points | Damage taken | Reduction |
|---|---|---|
| 0 | 100% | 0% |
| 10 | 18.2% | 81.8% |
| 20 (full diamond) | 10% | 90% |

Armor toughness is ignored. No Fabric API required, only Fabric Loader.

## Build the jar

Requires JDK 21 and an internet connection (first build downloads Minecraft + Fabric Loom).

    ./gradlew build        (Windows: gradlew.bat build)

The mod jar is `build/libs/armor-curve-1.0.0.jar` (ignore the `-sources` jar).
Drop it in your `mods` folder, or upload it to Modrinth.

## Want a strictly linear curve instead?

In `CombatRulesMixin.java` replace the formula with:

    cir.setReturnValue(damage * Math.max(0.1F, 1.0F - 0.045F * armorPoints));

(0 armor = 0% reduction, 20 armor = 90% reduction, evenly spaced.)
