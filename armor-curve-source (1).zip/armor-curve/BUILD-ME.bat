@echo off
echo Building Armor Curve (first run downloads Minecraft + Fabric, takes a few minutes)...
call gradlew.bat build
if errorlevel 1 (
  echo.
  echo BUILD FAILED - make sure JDK 21 is installed, then send me the error text above.
  pause
  exit /b 1
)
copy /Y build\libs\armor-curve-1.0.0.jar armor-curve-1.0.0.jar >nul
echo.
echo Done! Your mod is armor-curve-1.0.0.jar in this folder. Drop it in your mods folder.
pause
